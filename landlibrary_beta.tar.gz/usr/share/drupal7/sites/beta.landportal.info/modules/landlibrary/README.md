# LandLibrary

- Add the dependent modules (apachesolr_descr) to the sites/all/modules folder.
- Download the file http://jsonpath.googlecode.com/files/jsonpath-0.8.1.php and copy it in the sites/all/modules/feeds_jsonpath_parser folder.
- Follow the standard procedure to install LandLibrary as a feature. 
- Append the CSS code from includes/css/library.css to your site's template CSS code.
- Import taxonomies from the files in includes/taxonomies.
